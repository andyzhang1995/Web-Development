function toggleSongs() {
  document.getElementById("songs-second-half").classList.toggle("hidden")
}

document.getElementById("toggle-button").onclick = toggleSongs;
